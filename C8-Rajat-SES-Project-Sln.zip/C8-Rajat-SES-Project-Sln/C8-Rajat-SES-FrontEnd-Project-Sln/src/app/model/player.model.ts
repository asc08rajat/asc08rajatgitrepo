export class Player{
    id:number;
    player_id:string;
    player_name:string;
    player_age:number;
    player_role:string;   
    player_nationality:string;
}