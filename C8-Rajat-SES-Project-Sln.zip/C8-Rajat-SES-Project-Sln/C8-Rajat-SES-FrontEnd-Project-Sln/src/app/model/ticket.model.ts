export class Ticket {
    id: number;               
    ticket_id: string;   
    buyer_name: string;     
    seat_number: string;      
    ticket_price: number;     
    purchase_date: Date | string; 
  }