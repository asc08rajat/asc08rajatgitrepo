export class Teams{
    id:number;
    team_id:string;
    team_name:string;
    team_country:string;
    team_coach:string;
    team_captain:string;
    
}