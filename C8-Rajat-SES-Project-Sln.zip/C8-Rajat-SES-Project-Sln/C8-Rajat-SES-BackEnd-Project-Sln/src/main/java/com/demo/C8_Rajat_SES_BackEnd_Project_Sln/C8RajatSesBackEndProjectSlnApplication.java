package com.demo.C8_Rajat_SES_BackEnd_Project_Sln;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C8RajatSesBackEndProjectSlnApplication {

	public static void main(String[] args) {
		SpringApplication.run(C8RajatSesBackEndProjectSlnApplication.class, args);
	}

}
