package com.demo.C8_Rajat_SES_BackEnd_Project_Sln;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C8RajatSesBackEndProjectSlnApplicationTests {

	@Test
	void contextLoads() {
	}

}
