package com.demo.EFcitiShopSpringBootRESTAPIAscBlr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EFcitiShopSpringBootRestapiAscBlrApplication {

	public static void main(String[] args) {
		SpringApplication.run(EFcitiShopSpringBootRestapiAscBlrApplication.class, args);
	}

}
