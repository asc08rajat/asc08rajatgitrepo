package com.demo.EFcitiShopSpringBootRESTAPIAscBlr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EFcitiShopSpringBootRestapiAscBlrApplicationTests {

	@Test
	void contextLoads() {
	}

}
